import './App.css';
import {BrowserRouter,Route,Routes} from 'react-router-dom'
import Dashboard from './Components/Dashboard.js'
import 'bootstrap/dist/css/bootstrap.css'
import Login from './Components/Login.js'
import Rent from './Components/Rent.js'
import Bmw from './Components/Bmw.js'
import Thar from './Components/Thar.js'
import Benz from './Components/Benz.js'
import Roll from './Components/Roll.js'
import Audi from './Components/Audi.js'
import Kia from './Components/Kia.js'
import Nexon from './Components/Nexon.js'
import Hyundai from './Components/Hyundai.js'
import Brezza from './Components/Brezza.js'
import Book from './Components/Book.js'
function App() {
  return (
    <div>
     <BrowserRouter>
      <Routes>
      <Route path="/" element={<Login/>}/>
      <Route path="/Dashboard" element={<Dashboard/>}/>
      <Route path="/Bmw" element={<Bmw/>}/>
      <Route path="/Benz" element={<Benz/>}/>
      <Route path="/Roll" element={<Roll/>}/>
      <Route path="/Kia" element={<Kia/>}/>
      <Route path="/Thar" element={<Thar/>}/>
      <Route path="/Audi" element={<Audi/>}/>
      <Route path="/Hyundai" element={<Hyundai/>}/>
      <Route path="/Brezza" element={<Brezza/>}/>
      <Route path="/Nexon" element={<Nexon/>}/>
      <Route path="/Book" element={<Book/>}/>
      <Route path="/Rent" element={<Rent/>}/>
      </Routes>
      </BrowserRouter>
      {/* <Dashboard/> */}
       {/* <Header/> */}
    </div>
  );
}

export default App;

