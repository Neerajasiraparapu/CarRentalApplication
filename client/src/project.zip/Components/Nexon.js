import React from 'react'
import nexon from '../Images/nexon.png'
import {Link} from 'react-router-dom'
function Nexon() {
  return (
    <div className='container' id="container">
         <div className='row'>
           <div className='col-md-8' id='sem'></div>
           <div className='col-md-3' id='sem1'></div>
         </div><br/>
         <div className='row'>
            <center>
            <div className='col-md-6' id='sem2'></div>
            </center>
         </div><br/>
         <div className='row'>
        
           <div className='col-md-5' id='sem3'>
             <center>
             <img src={nexon} id='example'/>
             </center>
           </div>
           <div className='col-md-5' id='sem3'>
            <center>
                 <table>
                    <tr>
                        <td>CAR NAME :</td>
                        <td>NEXON</td>
                    </tr>
                    <tr>
                        <td>CAR MODEL :</td>
                        <td>2023</td>
                    </tr>
                    <tr>
                        <td>CAR PRICE :</td>
                        <td>30 Lakhs</td>
                    </tr>
                    <tr>
                        <td>CAR COLOUR :</td>
                        <td>Light Green</td>
                    </tr>
                 </table>
                 </center>
           </div>
         </div><br/>
         <center>
         <button type="submit" id='but1'><Link to='/Dashboard' id='demo'><p id='demo1'>BACK</p></Link></button>
         <button type="submit" id='but1'><Link to='/Book' id='demo'><p id='demo1'>BOOK</p></Link></button>
         </center>
    </div>
  )
}

export default Nexon