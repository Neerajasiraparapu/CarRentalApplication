import React from 'react'
//import {Link} from 'react-router-dom'
function Rent() {
  return (
    <div>
        RENT CARS
    </div>
  )
}

export default Rent