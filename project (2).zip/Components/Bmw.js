import React from 'react'
import bmw from '../Images/bmw.png'
import {Link} from 'react-router-dom'
function Bmw() {
  return (
    <div className='container' id="container">
         <div className='row'>
           <div className='col-md-8' id='sem'><h2 id='rental'>CAR RENTAL APPLICATION</h2></div>
           <div className='col-md-3' id='sem1'></div>
         </div><br/>
         <div className='row'>
            <center>
            <div className='col-md-6' id='sem2'></div>
            </center>
         </div><br/>
         <div className='row'>
        
           <div className='col-md-5' id='sem3'>
             <center>
             <img src={bmw} id='example'/>
             </center>
           </div>
           <div className='col-md-5' id='sem3'>
            <center>
                 <table>
                    <tr>
                        <td>CAR NAME :</td>
                        <td>BMW</td>
                    </tr>
                    <tr>
                        <td>CAR MODEL :</td>
                        <td>2023</td>
                    </tr>
                    <tr>
                        <td>CAR PRICE :</td>
                        <td>42 Lakhs</td>
                    </tr>
                    <tr>
                        <td>CAR COLOUR :</td>
                        <td>Light Brown</td>
                    </tr>
                 </table>
                 </center>
           </div>
         </div><br/>
         <center>
         <button type="submit" id='but1'><Link to='/Dashboard' id='demo'><p id='demo1'>BACK</p></Link></button>
         <button type="submit" id='but1'><Link to='/Book' id='demo'><p id='demo1'>BOOK</p></Link></button>
         </center>
    </div>
  )
}

export default Bmw