import React from 'react'
import kia from '../Images/kia.png'
import {Link} from 'react-router-dom'
function Kia() {
  return (
    <div className='container' id="container">
         <div className='row'>
           <div className='col-md-8' id='sem'><h2 id='rental'>CAR RENTAL APPLICATION</h2></div>
           <div className='col-md-3' id='sem1'></div>
         </div><br/>
         <div className='row'>
            <center>
            <div className='col-md-6' id='sem2'><h3 id='rental1'>CAR ID</h3></div>
            </center>
         </div><br/>
         <div className='row'>
        
           <div className='col-md-5' id='sem3'>
             <center>
             <img src={kia} id='example'/>
             </center>
           </div>
           <div className='col-md-5' id='sem3'>
            <center>
                 <table>
                    <tr>
                        <td>CAR NAME :</td>
                        <td>KIA</td>
                    </tr>
                    <tr>
                        <td>CAR MODEL :</td>
                        <td>2023</td>
                    </tr>
                    <tr>
                        <td>CAR PRICE :</td>
                        <td>33 Lakhs</td>
                    </tr>
                    <tr>
                        <td>CAR COLOUR :</td>
                        <td>Red</td>
                    </tr>
                 </table>
                 </center>
           </div>
         </div><br/>
         <center>
         <button type="submit" id='but1'><Link to='/Dashboard' id='demo'><p id='demo1'>BACK</p></Link></button>
         <button type="submit" id='but1'><Link to='/Book' id='demo'><p id='demo1'>BOOK</p></Link></button>
         </center>
    </div>
  )
}

export default Kia