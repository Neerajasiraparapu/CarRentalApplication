import React from 'react'
import './Navbar.css'
import {Link} from 'react-router-dom'
import group from '../Images/group5.png'
//import {Link} from 'react-router-dom'
function Navbar() {
  return (
    <div style={{backgroundImage:`url(${group})`,height:"1000px",backgroundRepeat: "no-repeat",backgroundSize: "cover"}} >
    <div className="nav" >
  <input type="checkbox" id="nav-check"/>
  <div className="nav-header">
    <div className="nav-title">
      <h3>CAR RENTAL</h3>
    </div>
  </div>
  <div className="nav-btn">
    <label for="nav-check">
      <span></span>
      <span></span>
      <span></span>
    </label>
  </div>
  
  <div className="nav-links">
    {/* <a href="//github.io/jo_geek" target="_blank">Github</a> */}
    {/* <a href="http://stackoverflow.com/users/4084003/" target="_blank">Stackoverflow</a> */}
    <a href="/"><Link to="/Login"><h4>User Login</h4></Link></a>
    <a href="/"><Link><h4>Admin Login</h4></Link></a>
    <a href="/"><Link><h4>Owner Login</h4></Link></a>
  </div><br/>
</div>
</div>
  )
}

export default Navbar